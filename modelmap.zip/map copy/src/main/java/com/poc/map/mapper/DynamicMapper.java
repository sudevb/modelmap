package com.poc.map.mapper;

import com.poc.map.dto.ProductDto;
import com.poc.map.dto.RiskDto;
import com.poc.map.dto.StageDto;
import com.poc.map.dto.TradeDto;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Component;

@Component
@AllArgsConstructor
@NoArgsConstructor
public class DynamicMapper {

    @Autowired
    private ModelMapper modelMapper;

    public void setMap () {
        modelMapper.typeMap(StageDto.class, ProductDto.class).addMappings(mapper -> {
            mapper.map(src -> parseField(src.getRecord(), 0), ProductDto::setName);
            mapper.map(src -> parseField(src.getRecord(), 1), ProductDto::setDescription);
        });

        modelMapper.typeMap(StageDto.class, RiskDto.class).addMappings(mapper -> {
            mapper.map(src -> parseField(src.getRecord(), 0), RiskDto::setRiskId);
            mapper.map(src -> parseField(src.getRecord(), 1), RiskDto::setRiskDescription);
        });

        modelMapper.typeMap(StageDto.class, TradeDto.class).addMappings(mapper -> {
            mapper.map(src -> parseField(src.getRecord(), 0), TradeDto::setTradeId);
            mapper.map(src -> parseField(src.getRecord(), 1), TradeDto::setTradeCategory);
            mapper.map(src -> parseField(src.getRecord(), 2), TradeDto::setTradeType);
        });
    }
    public ProductDto toProductDto(StageDto stageDto) {
        return modelMapper.map(stageDto, ProductDto.class);
    }

    public RiskDto toRiskDto(StageDto stageDto) {
        return modelMapper.map(stageDto, RiskDto.class);
    }

    public TradeDto toTradeDto(StageDto stageDto) {
        return modelMapper.map(stageDto, TradeDto.class);
    }

    private String parseField(String record, int index) {
        String[] fields = record.split(",");
        return fields.length > index ? fields[index] : null;
    }
}
