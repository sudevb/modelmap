package com.poc.map.controller;

import com.poc.map.dto.ProductDto;
import com.poc.map.dto.RiskDto;
import com.poc.map.dto.StageDto;
import com.poc.map.dto.TradeDto;
import com.poc.map.service.MappingService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api")
public class MapController {

    @Autowired
    private MappingService mappingService;

    @GetMapping("/testProduct")
    public ProductDto mapProduct() {
        StageDto stageDto = new StageDto("product,description", "ProductType");
        return (ProductDto) mappingService.mapToTarget(stageDto);
    }

    @GetMapping("/testRisk")
    public RiskDto mapRisk() {
        StageDto stageDto = new StageDto("riskid1,description1", "RiskType");
        return (RiskDto) mappingService.mapToTarget(stageDto);
    }

    @GetMapping("/testTrade")
    public TradeDto mapTrade() {
        StageDto stageDto = new StageDto("record,category,type", "TradeType");
        return (TradeDto) mappingService.mapToTarget(stageDto);
    }

    @GetMapping("/map")
    public Object map(@RequestParam String record, @RequestParam String type) {
        StageDto stageDto = new StageDto(record, type);
        return mappingService.mapToTarget(stageDto);
    }
}
